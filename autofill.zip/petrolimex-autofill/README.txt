Cài đặt Extension iTaxViewer Invoice Autofill

1. Mở Chrome hoặc Edge và truy cập:
   chrome://extensions/
   hoặc edge://extensions/
2. Bật Developer mode / Chế độ nhà phát triển.
3. Chọn Load unpacked / Tải tiện ích đã giải nén.
4. Chọn thư mục petrolimex-autofill.
5. Bấm Reload extension nếu đã cài từ trước.
6. Mở menu Extensions (biểu tượng mảnh ghép), tìm "iTaxViewer Invoice Autofill" và bấm ghim để icon hiện cố định trên thanh trình duyệt.

Extension có icon riêng màu xanh ngọc hình tài liệu/kiểm tra. Nút trên thanh trình duyệt dùng để nhận diện extension; việc tự điền vẫn được kích hoạt khi mở liên kết tra cứu từ iTaxViewer.

Cách dùng

- Từ iTaxViewer: bấm nút tra cứu nhà cung cấp. Extension sẽ tự điền mã trong URL fragment.
- Hỗ trợ Petrolimex, Sapo Invoice, Viettel Vinvoice và CellphoneS.
- CellphoneS dùng trường "Mã nhận hóa đơn" và mã được truyền từ XML qua `TTKhac/TTin`.
- Với Viettel, extension tự điền thêm MST bên bán nếu XML có thông tin người bán.
- Mở trang thủ công: bấm "Dán mã từ clipboard", hoặc dùng Ctrl+V.
- Extension làm nổi bật ảnh CAPTCHA, đưa focus vào ô CAPTCHA và có nút "Làm mới CAPTCHA" khi trang cung cấp ảnh CAPTCHA.
- CAPTCHA không được tự động giải; người dùng vẫn cần đọc/nhập thủ công.
- Sau khi nhập CAPTCHA, focus sẽ chuyển tới nút "Tìm kiếm".
- CAPTCHA vẫn phải nhập thủ công và người dùng tự bấm Tìm kiếm.

Extension chỉ hoạt động trên:
https://hoadon.petrolimex.com.vn/SearchInvoicebycode/Index
https://sapo.vn/tra-cuu-sapo-invoice.html
https://vinvoice.viettel.vn/utilities/invoice-search
https://hddt.cellphones.com.vn/tra-cuu-hoa-don
