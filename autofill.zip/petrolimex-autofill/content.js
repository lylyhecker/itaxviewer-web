(function () {
    'use strict';

    const CODE_FIELD_ID = 'strFkey';
    const CAPTCHA_FIELD_ID = 'captch';
    const STATUS_ID = 'itaxviewer-petrolimex-status';
    const BUTTON_ID = 'itaxviewer-petrolimex-paste';
    const CAPTCHA_REFRESH_ID = 'itaxviewer-petrolimex-refresh-captcha';
    const FILL_RETRY_LIMIT = 40;
    let fillAttempts = 0;

    function getPayloadFromHash() {
        const raw = location.hash.replace(/^#/, '');
        const encoded = raw.indexOf('itaxviewer=') === 0 ? raw.slice('itaxviewer='.length) : '';
        try {
            const params = new URLSearchParams(encoded ? decodeURIComponent(encoded) : raw);
            return {
                code: (params.get('code') || '').trim(),
                mst: (params.get('mst') || '').trim()
            };
        } catch (error) {
            return { code: '', mst: '' };
        }
    }

    function getProvider() {
        if (location.hostname.includes('petrolimex')) return 'petrolimex';
        if (location.hostname.includes('sapo')) return 'sapo';
        if (location.hostname.includes('viettel')) return 'viettel';
        if (location.hostname.includes('cellphones')) return 'cellphones';
        return '';
    }

    function showStatus(message, isError) {
        let status = document.getElementById(STATUS_ID);
        if (!status) {
            status = document.createElement('div');
            status.id = STATUS_ID;
            status.style.cssText = [
                'margin:10px 0',
                'padding:8px 10px',
                'border-radius:4px',
                'font:13px/1.4 Arial,sans-serif',
                'background:#e8f5f2',
                'color:#165c55',
                'border:1px solid #9fd1c8'
            ].join(';');
            const field = document.getElementById(CODE_FIELD_ID);
            if (field && field.parentElement) field.parentElement.appendChild(status);
        }
        if (!status) return;
        status.textContent = message;
        status.style.background = isError ? '#fff1f0' : '#e8f5f2';
        status.style.color = isError ? '#9b3028' : '#165c55';
        status.style.borderColor = isError ? '#e2aaa5' : '#9fd1c8';
    }

    function fillCode(code) {
        const field = document.getElementById(CODE_FIELD_ID) || findProviderField('code');
        if (!field || !code) return false;
        setFieldValue(field, code);
        field.focus();
        return true;
    }

    function setFieldValue(field, value) {
        const prototype = Object.getPrototypeOf(field);
        const descriptor = prototype && Object.getOwnPropertyDescriptor(prototype, 'value');
        if (descriptor && descriptor.set) descriptor.set.call(field, value);
        else field.value = value;
        field.dispatchEvent(new Event('input', { bubbles: true }));
        field.dispatchEvent(new Event('change', { bubbles: true }));
        field.dispatchEvent(new Event('blur', { bubbles: true }));
    }

    function findProviderField(kind) {
        const provider = getProvider();
        const selectors = provider === 'cellphones'
            ? (kind === 'code'
                ? ['input[name*="code" i]', 'input[id*="code" i]', 'input[placeholder*="nhận hóa đơn" i]', 'input[aria-label*="nhận hóa đơn" i]', 'form input[type="text"]:first-of-type']
                : [])
            : provider === 'sapo'
            ? (kind === 'code'
                ? ['#reference_code', '#voucher_reference_code', 'input[name*="code" i]', 'input[id*="code" i]', 'input[placeholder*="tra cứu" i]', 'input[placeholder*="mã" i]']
                : [])
            : provider === 'viettel'
                ? (kind === 'code'
                    ? ['input[formcontrolname="reservationCode"]', 'input[name*="secret" i]', 'input[id*="secret" i]', 'input[name*="lookup" i]', 'input[id*="lookup" i]', 'input[placeholder*="bí mật" i]', 'input[placeholder*="tra cứu" i]']
                    : ['input[formcontrolname="supplierTaxCode"]', 'input[name*="seller" i][name*="tax" i]', 'input[id*="seller" i][id*="tax" i]', 'input[placeholder*="MST bên bán" i]', 'input[placeholder*="mã số thuế bên bán" i]'])
                : [];
        for (const selector of selectors) {
            const field = document.querySelector(selector);
            if (field) return field;
        }
        if (kind === 'mst' && provider === 'viettel') {
            return findField(['mst bên bán', 'mã số thuế bên bán', 'tax code người bán', 'seller tax']);
        }
        return findField(kind === 'code'
            ? ['strFkey', 'lookup', 'secret', 'mã tra cứu', 'mã số bí mật', 'mã nhận hóa đơn', 'code for checking', 'invoice code', 'invoice lookup']
            : ['mst bên bán', 'mã số thuế bên bán', 'seller tax']);
    }

    function findField(tokens) {
        const fields = Array.from(document.querySelectorAll('input:not([type="hidden"]), textarea'));
        return fields.find(field => {
            const text = [
                field.id, field.name, field.placeholder, field.getAttribute('aria-label'),
                field.closest('label')?.textContent,
                field.parentElement?.textContent
            ].filter(Boolean).join(' ').toLowerCase();
            return tokens.some(token => text.includes(token.toLowerCase()));
        });
    }

    function fillProviderFields(payload) {
        const provider = getProvider();
        if (provider === 'viettel') {
            const mstField = findProviderField('mst');
            if (payload.mst && mstField) fillField(mstField, payload.mst);
            return Boolean(fillCode(payload.code));
        }
        return fillCode(payload.code);
    }

    function fillField(field, value) {
        if (!field || !value) return false;
        setFieldValue(field, value);
        return true;
    }

    function getCaptchaField() {
        if (getProvider() === 'cellphones') {
            const codeField = findProviderField('code');
            const fields = Array.from(document.querySelectorAll('input[type="text"], input:not([type])'));
            return fields.find(field => field !== codeField && /kiểm tra|captcha|mã kiểm tra/i.test([
                field.id, field.name, field.placeholder, field.getAttribute('aria-label'),
                field.parentElement?.textContent
            ].filter(Boolean).join(' '))) || fields.find(field => field !== codeField);
        }
        return document.getElementById(CAPTCHA_FIELD_ID);
    }

    function focusCaptcha() {
        const field = getCaptchaField();
        if (!field) return;
        field.style.outline = '3px solid rgba(22, 135, 128, .45)';
        field.style.outlineOffset = '2px';
        field.focus();
        field.addEventListener('input', function onInput() {
            if (field.value.trim()) {
                const submit = document.querySelector('#SearchformByfkey input[type="submit"], #SearchformByfkey button[type="submit"], button[type="submit"]');
                if (submit) submit.focus();
                field.removeEventListener('input', onInput);
            }
        });
    }

    function refreshCaptcha() {
        const image = document.querySelector('#SearchformByfkey img.captcha_img, #SearchformByfkey img[src*="/Captcha/"]');
        if (!image) return;
        const separator = image.src.includes('?') ? '&' : '?';
        image.src = image.src.split(/[?&]v=/)[0] + separator + 'v=' + Date.now();
        focusCaptcha();
    }

    function addProviderStatus(payload) {
        const provider = getProvider();
        if (!payload.code || !provider) return;
        const name = provider === 'sapo' ? 'Sapo' : provider === 'viettel' ? 'Viettel' :
            provider === 'cellphones' ? 'CellphoneS' : 'Petrolimex';
        showStatus('Đã tự điền mã tra cứu ' + name + (provider === 'viettel' && payload.mst ? ' và MST bên bán' : '') + '.', false);
    }

    function addCaptchaHelpers() {
        const field = getCaptchaField();
        if (!field || document.getElementById(CAPTCHA_REFRESH_ID)) return;
        const image = document.querySelector('#SearchformByfkey img.captcha_img, #SearchformByfkey img[src*="/Captcha/"]');
        if (image) {
            image.style.outline = '2px solid rgba(22, 135, 128, .35)';
            image.style.outlineOffset = '3px';
            image.title = 'Đọc mã CAPTCHA rồi nhập vào ô bên cạnh';
        }
        if (getProvider() !== 'cellphones' && !image) return;
        const button = document.createElement('button');
        button.id = CAPTCHA_REFRESH_ID;
        button.type = 'button';
        button.textContent = 'Làm mới CAPTCHA';
        button.style.cssText = [
            'margin-left:8px',
            'padding:6px 10px',
            'border:1px solid #9fd1c8',
            'border-radius:4px',
            'background:#e8f5f2',
            'color:#165c55',
            'cursor:pointer'
        ].join(';');
        button.addEventListener('click', refreshCaptcha);
        field.insertAdjacentElement('afterend', button);
        field.setAttribute('aria-label', 'Nhập mã CAPTCHA trong hình');
    }

    function addPasteButton() {
        const field = document.getElementById(CODE_FIELD_ID) || findProviderField('code');
        if (!field || document.getElementById(BUTTON_ID)) return;
        const button = document.createElement('button');
        button.id = BUTTON_ID;
        button.type = 'button';
        button.textContent = 'Dán mã từ clipboard';
        button.style.cssText = [
            'margin-left:8px',
            'padding:6px 10px',
            'border:1px solid #9fd1c8',
            'border-radius:4px',
            'background:#e8f5f2',
            'color:#165c55',
            'cursor:pointer'
        ].join(';');
        button.addEventListener('click', async function () {
            try {
                const code = (await navigator.clipboard.readText()).trim();
                if (!code) throw new Error('empty');
                fillCode(code);
                showStatus('Đã điền mã tra cứu từ clipboard. Vui lòng nhập CAPTCHA.', false);
            } catch (error) {
                showStatus('Không đọc được clipboard. Hãy cấp quyền hoặc dán mã bằng Ctrl+V.', true);
            }
        });
        field.insertAdjacentElement('afterend', button);
    }

    function init() {
        const payload = getPayloadFromHash();
        if (payload.code && fillProviderFields(payload)) {
            fillAttempts = 0;
            history.replaceState(null, document.title, location.pathname + location.search);
            addProviderStatus(payload);
            focusCaptcha();
        } else if (payload.code && fillAttempts < FILL_RETRY_LIMIT) {
            fillAttempts += 1;
            window.setTimeout(init, 250);
        }
        addPasteButton();
        addCaptchaHelpers();
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init, { once: true });
    } else {
        init();
    }

    new MutationObserver(init).observe(document.documentElement, { childList: true, subtree: true });
})();
